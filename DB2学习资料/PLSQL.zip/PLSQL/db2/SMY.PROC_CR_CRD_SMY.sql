CREATE PROCEDURE SMY.PROC_CR_CRD_SMY(IN ACCOUNTING_DATE date)
-------------------------------------------------------------------------------
-- (C) Copyright ZJRCU and IBM <date>
--
-- File name:           SMY.PROC_CR_CRD_SMY.sql
-- Procedure name: 			SMY.PROC_CR_CRD_SMY
-- Source Table:				SOR.CR_CRD,SOR.CRD,SOR.CC_AC_AR,SOR.CC_REPYMT_TXN_DTL,SOR.CC_INT_RCVB_RGST
-- Target Table: 				SMY.CR_CRD_SMY
-- Project     :        ZJ RCCB EDW
-- NOTES       :        
-- Purpose     :            
-- PROCESS METHOD      :  empty and INSERT
--=============================================================================
-- Creation Date:       2009.11.12
-- Origin Author:       JAMES SHANG IBM copyright 
--
-- Version: %1.0%
--
-- Modification History
-- --------------------
--
-- Date         ByPerson        Description
-- ----------   --------------  -----------------------------------------------
-- 2009-11-12   JAMES SHANG     Create SP File		
-- 2009-11-19   Xu Yan          Added two new columns
-- 2009-11-24   Xu Yan          Updated some conditional statements
-- 2010-01-19   Xu Yan          Updated AMT_RCVD_For_LST_TM_OD getting rules
-- 2010-05-21   Xu Yan          Added a column 'DRMT_CRD_F', please refer to SMY.PROC_CRD_PRFL_CRD_DLY_SMY.
-- 2011-04-21   Wang You Bing   Added a column 'INT_RCVB_EXCPT_OFF_BST';Added DEL_F on each SOR table
-- 2013-02-26   Chen XiaoWen    添加卡介质字段SOR.CRD.CRD_MEDA_TP_ID
-- 2013-05-30   Chen XiaoWen    配合信用卡系统改造
-- 2014-03-03   CHEN PENG       OTSND_AMT_RCVB修改映射规则，新增字段LGR_INSTL_LMT
-- 2014-03-31   CHEN PENG       新增字段INSTL_BAL
-------------------------------------------------------------------------------
LANGUAGE SQL
BEGIN
    /*声明异常处理使用变量*/
    DECLARE SQLCODE, SMY_SQLCODE INT DEFAULT 0;     --SQLCODE
    DECLARE SMY_STEPNUM INT DEFAULT 1;              --过程内部位置标记
    DECLARE SMY_STEPDESC VARCHAR(100) DEFAULT '';   --过程内部位置描述
    DECLARE SMY_DATE DATE;                          --临时日期变量
    DECLARE SMY_RCOUNT INT;                         --DML语句作用记录数
    DECLARE SMY_PROCNM VARCHAR(100);                --存储过程名称
    
    /*声明存储过程使用变量*/
    DECLARE CUR_YEAR SMALLINT;--
    DECLARE CUR_MONTH SMALLINT;--
    DECLARE CUR_MTH_YEAR CHAR(6);--
    DECLARE V_T SMALLINT;--
    DECLARE EMP_SQL VARCHAR(200);--
    DECLARE RECORD_NUM BIGINT;--
		
    /*
    	1.定义针对SQL异常情况的句柄(EXIT方式).
      2.将出现SQL异常时在存储过程中的位置(SMY_STEPNUM),位置描述(SMY_STEPDESC),SQLCODE(SMY_SQLCODE)记入表SMY_LOG中作调试用.
      3.调用RESIGNAL重新引发异常,跳出存储过程执行体,对引发SQL异常之前存储过程体中所完成的操作进行回滚.
    */
    DECLARE CONTINUE HANDLER FOR NOT FOUND
		    SET V_T=0;--
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET SMY_SQLCODE = SQLCODE;--
        ROLLBACK;--
        INSERT INTO SMY.SMY_LOG VALUES(SMY_PROCNM, SMY_DATE, SMY_STEPNUM, SMY_STEPDESC, SMY_SQLCODE, NULL, CURRENT TIMESTAMP);--
        COMMIT;--
        RESIGNAL;--
    END;--
    DECLARE CONTINUE HANDLER FOR SQLWARNING
    BEGIN
        SET SMY_SQLCODE = SQLCODE;--
        INSERT INTO SMY.SMY_LOG VALUES(SMY_PROCNM, SMY_DATE, SMY_STEPNUM, SMY_STEPDESC, SMY_SQLCODE, NULL, CURRENT TIMESTAMP);--
        COMMIT;--
    END;--
    
    /*变量赋值*/
    SET SMY_PROCNM  ='PROC_CR_CRD_SMY';--
    SET SMY_DATE    =ACCOUNTING_DATE;--
    SET CUR_YEAR    =YEAR(ACCOUNTING_DATE);    --取当前年份
    SET CUR_MONTH   =MONTH(ACCOUNTING_DATE);   --取当前月份
    
    IF CUR_MONTH<10 
    THEN 
        SET CUR_MTH_YEAR = CUR_YEAR||'0'||CUR_MONTH;--
    ELSE 
        SET CUR_MTH_YEAR = CUR_YEAR||CUR_MONTH;--
    END IF;--
    
    /*Delete日志表,条件SMY_PROCNM=当前存储过程名字,SMY_DATE=ACCOUNTING_DATE,并插入新的起始标志*/
    DELETE FROM SMY.SMY_LOG WHERE SMY_ACT_DT = SMY_DATE AND SMY_PROC_NM = SMY_PROCNM;--
    COMMIT;--
    
    GET DIAGNOSTICS SMY_RCOUNT = ROW_COUNT;--
    SET SMY_STEPDESC = 	'存储过程开始运行';--
    INSERT INTO SMY.SMY_LOG (SMY_PROC_NM,SMY_ACT_DT,SMY_STEPNUM,SMY_STEPDESC,SMY_SQLCODE,SMY_RCOUNT,CUR_TS)
        VALUES(SMY_PROCNM, SMY_DATE, SMY_STEPNUM, SMY_STEPDESC, SMY_SQLCODE, SMY_RCOUNT, CURRENT TIMESTAMP);--
    SET SMY_STEPNUM = 2;--
    SET SMY_STEPDESC = '声明临时表,存放从SOR.CC_AC_AR汇总后的数据';--
    
    DECLARE GLOBAL TEMPORARY TABLE T_CC_AC_AR AS (
        SELECT
             CC_AC_AR_ID AS CC_AC_AR_ID
            ,AST_RSK_ASES_RTG_TP_CD AS AST_RSK_ASES_RTG_TP_CD
            ,LN_FR_RSLT_TP_ID AS LN_FIVE_RTG_STS
            ,-BAL_AMT AS AC_BAL_AMT              --账户余额(其实是本金余额,小于0是透支,大于0有存款)
            ,(CASE WHEN BAL_AMT >=0 THEN 0 ELSE -BAL_AMT END) AS DEP_BAL_CRD                               --银行卡存款余额
            ,(CASE WHEN BAL_AMT <0 THEN 0 ELSE (BAL_AMT+ODUE_INT_AMT+FEE_AMT_DUE) END) AS OD_BAL_AMT       --透支余额
            ,(CASE WHEN BAL_AMT >0 THEN BAL_AMT ELSE 0 END ) AS AMT_PNP_ARS                                --透支本金
            --(CASE WHEN BAL_AMT+ODUE_INT_AMT+FEE_AMT_DUE >0 THEN -(BAL_AMT+ODUE_INT_AMT+FEE_AMT_DUE+INSTL_BAL) 
             --   ELSE INSTL_BAL 
             -- END) AS OTSND_AMT_RCVB            --应收账款余额 20140303 CHENPENG DELETE
            ,FEE_AMT_DUE AS FEE_RCVB            --应收费用
            ,ODUE_INT_AMT AS INT_RCVB           --应收利息
            ,TMP_CRED_LMT_AMT AS TMP_CRED_LMT   --临时授信金额
            ,CR_LMT                             --授信额度
            ,DEP_ACG_SBJ_ID                     --存款科目
            ,OD_ACG_SBJ_ID                      --透支科目
            ,(CASE WHEN PREV_STA_BAL_AMT<=0 THEN 0 
                ELSE (PREV_STA_BAL_AMT-PRV_STMT_INT_BAL-PRV_STMT_CNSPN_BAL-PRV_STMT_CASH_ADV_BAL
                      -PRV_STMT_FEE_BAL-PRV_STMT_INSTL_BAL) 
              END) AS AMT_RCVD_FOR_LST_TM_OD    --本期还的上个月之前的金额
            ,CMPD_INT_BAL                       --复利余额
            ,AR_LCS_TP_ID                       --账户状态
            ,CASH_ADV_AMT                       --当前取现透支金额
            ,PRV_STMT_CNSPN_BAL                 --上期账单消费余额
            ,PRV_STMT_INT_BAL                   --上期账单利息余额
            ,PRV_STMT_INSTL_BAL                 --上期账单分期付款余额
            ,INSTL_BAL                          --分期付款金额 20140303 CHENPENG ADD
        FROM SOR.CC_AC_AR
    ) DEFINITION ONLY ON COMMIT PRESERVE ROWS NOT LOGGED WITH REPLACE PARTITIONING KEY(CC_AC_AR_ID) IN TS_USR_TMP32K;--
    
    INSERT INTO SESSION.T_CC_AC_AR 
    SELECT 
         CC_AC_AR_ID AS CC_AC_AR_ID
        ,AST_RSK_ASES_RTG_TP_CD AS AST_RSK_ASES_RTG_TP_CD
        ,LN_FR_RSLT_TP_ID AS LN_FIVE_RTG_STS
        ,-BAL_AMT AS AC_BAL_AMT              --账户余额(其实是本金余额,小于0是透支,大于0有存款)
        ,(CASE WHEN BAL_AMT >=0 THEN 0 ELSE -BAL_AMT END)  AS DEP_BAL_CRD                              --银行卡存款余额
        ,(CASE WHEN BAL_AMT <0 THEN 0 ELSE (BAL_AMT+ODUE_INT_AMT+FEE_AMT_DUE) END) AS OD_BAL_AMT       --透支余额
        ,(CASE WHEN BAL_AMT >0 THEN BAL_AMT ELSE 0 END )  AS AMT_PNP_ARS                               --透支本金
        --(CASE WHEN BAL_AMT+ODUE_INT_AMT+FEE_AMT_DUE >0 THEN -(BAL_AMT+ODUE_INT_AMT+FEE_AMT_DUE+INSTL_BAL) 
         --   ELSE INSTL_BAL 
         -- END) AS OTSND_AMT_RCVB            --应收账款余额 20140303 CHENPENG DELETE
        ,FEE_AMT_DUE AS FEE_RCVB            --应收费用
        ,ODUE_INT_AMT AS INT_RCVB           --应收利息
        ,TMP_CRED_LMT_AMT AS TMP_CRED_LMT   --临时授信金额
        ,CR_LMT                             --授信额度
        ,DEP_ACG_SBJ_ID                     --存款科目
        ,OD_ACG_SBJ_ID                      --透支科目
        ,(CASE WHEN PREV_STA_BAL_AMT<=0 THEN 0 
            ELSE (PREV_STA_BAL_AMT-PRV_STMT_INT_BAL-PRV_STMT_CNSPN_BAL-PRV_STMT_CASH_ADV_BAL
                  -PRV_STMT_FEE_BAL-PRV_STMT_INSTL_BAL) 
          END) AS AMT_RCVD_FOR_LST_TM_OD    --本期还的上个月之前的金额
        ,CMPD_INT_BAL                       --复利余额
        ,AR_LCS_TP_ID                       --账户状态
        ,CASH_ADV_AMT                       --当前取现透支金额
        ,PRV_STMT_CNSPN_BAL                 --上期账单消费余额
        ,PRV_STMT_INT_BAL                   --上期账单利息余额
        ,PRV_STMT_INSTL_BAL                 --上期账单分期付款余额
        ,INSTL_BAL                          --分期付款金额 20140303 CHENPENG ADD
    FROM SOR.CC_AC_AR
    WHERE DEL_F=0;--
    
    SELECT count(1) INTO RECORD_NUM FROM HIS.CR_CRD_SMY;--
    
    IF RECORD_NUM=0
    THEN
        /*如果因任务报错误将HIS.CR_CRD_SMY清空,需要先恢复,否则客户最后活动日期会丢失.*/
        GET DIAGNOSTICS SMY_RCOUNT = ROW_COUNT;--
        INSERT INTO SMY.SMY_LOG (SMY_PROC_NM,SMY_ACT_DT,SMY_STEPNUM,SMY_STEPDESC,SMY_SQLCODE,SMY_RCOUNT,CUR_TS)
          VALUES(SMY_PROCNM, SMY_DATE, SMY_STEPNUM, SMY_STEPDESC, SMY_SQLCODE, SMY_RCOUNT, CURRENT TIMESTAMP);--
        SET SMY_STEPNUM = 3;--
        SET SMY_STEPDESC = '恢复昨日的客户最后活动日期到HIS表';--

        CALL SYSPROC.ADMIN_CMD('LOAD FROM (select CRD_NO,LST_CST_AVY_DT from SMY.CR_CRD_SMY)
                                  OF CURSOR REPLACE INTO HIS.CR_CRD_SMY');--
    END IF;--
    
    /*收集操作信息*/
    GET DIAGNOSTICS SMY_RCOUNT = ROW_COUNT;--
    INSERT INTO SMY.SMY_LOG (SMY_PROC_NM,SMY_ACT_DT,SMY_STEPNUM,SMY_STEPDESC,SMY_SQLCODE,SMY_RCOUNT,CUR_TS) 
        VALUES(SMY_PROCNM, SMY_DATE, SMY_STEPNUM, SMY_STEPDESC, SMY_SQLCODE, SMY_RCOUNT, CURRENT TIMESTAMP);--
    SET SMY_STEPNUM = 4;--
    SET SMY_STEPDESC = '根据当天交易明细更新客户最后活动日期';--

    DECLARE GLOBAL TEMPORARY TABLE TMP_LST_CST_AVY_DT(
         CRD_NO           CHARACTER(19)   --卡号
        ,LST_CST_AVY_DT   DATE            --客户最后活动日期
        ,AMT_RCVD         DECIMAL(17,2)   --已还款金额
    ) ON COMMIT PRESERVE ROWS NOT LOGGED WITH REPLACE IN TS_USR_TMP32K PARTITIONING KEY(CRD_NO);--

    INSERT INTO SESSION.TMP_LST_CST_AVY_DT
    SELECT
         CR_CRD_SMY.CRD_NO
        ,MAX(CASE WHEN CC_AC_TXN_DTL.ABS_CODE in (1010,1040,1110,1180,1184,8100,8104,8106,1000,1022,6000,6010,6110,6180,
                                                  6184,8102,8108,6022,2000,2050,2300,2350,8110,2010,2060,2310,2360,8112,
                                                  8114,8116,2110,2160,2180,2182,2184,2410,2460,2480,2482,2484,2090,2106,
                                                  2042,2072,2342,2372,2040,2070,2340,2370,2140,2170,2440,2470,2048,2102,
                                                  2402,2092,2094,7056,7000,8140,7040,7012,7062,7010,7060,7070,7080,7082,
                                                  7098,7032,7050,7054) 
               AND CC_AC_TXN_DTL.VCHR_NO is not null THEN SMY_DATE ELSE CR_CRD_SMY.LST_CST_AVY_DT END
         ) AS LST_CST_AVY_DT   --客户最后活动日期
        ,SUM(
            CASE WHEN 
                CC_AC_TXN_DTL.ABS_CODE in (7000,8140,7040,7012,7062,7010,7060,7070,7080,7082,7098,7032,7050,7054)
            THEN
                CASE WHEN DB_CR_IND=14280001 THEN -TXN_AMT ELSE TXN_AMT END
            ELSE 0 
            END
        ) AS AMT_RCVD         --已还款金额
    FROM HIS.CR_CRD_SMY AS CR_CRD_SMY
    LEFT JOIN SOR.CC_AC_TXN_DTL AS CC_AC_TXN_DTL 
        ON CR_CRD_SMY.CRD_NO=CC_AC_TXN_DTL.VCHR_NO AND CC_AC_TXN_DTL.TXN_DT=SMY_DATE
    GROUP BY CR_CRD_SMY.CRD_NO
    ;--
    
    /*收集操作信息*/
    GET DIAGNOSTICS SMY_RCOUNT = ROW_COUNT;--
    INSERT INTO SMY.SMY_LOG (SMY_PROC_NM,SMY_ACT_DT,SMY_STEPNUM,SMY_STEPDESC,SMY_SQLCODE,SMY_RCOUNT,CUR_TS)
      VALUES(SMY_PROCNM, SMY_DATE, SMY_STEPNUM, SMY_STEPDESC, SMY_SQLCODE, SMY_RCOUNT, CURRENT TIMESTAMP);--
    SET SMY_STEPNUM = 5;--
    SET SMY_STEPDESC = '清空SMY.CR_CRD_SMY';--

    SET EMP_SQL= 'ALTER TABLE SMY.CR_CRD_SMY ACTIVATE NOT LOGGED INITIALLY WITH EMPTY TABLE';--
    EXECUTE IMMEDIATE EMP_SQL;--
    COMMIT;--
    
    /*收集操作信息*/
    GET DIAGNOSTICS SMY_RCOUNT = ROW_COUNT;--
    INSERT INTO SMY.SMY_LOG (SMY_PROC_NM,SMY_ACT_DT,SMY_STEPNUM,SMY_STEPDESC,SMY_SQLCODE,SMY_RCOUNT,CUR_TS)
        VALUES(SMY_PROCNM, SMY_DATE, SMY_STEPNUM, SMY_STEPDESC, SMY_SQLCODE, SMY_RCOUNT, CURRENT TIMESTAMP);--
    SET SMY_STEPNUM = 6;--
    SET SMY_STEPDESC = '往汇总表CR_CRD_SMY,插入当日的数据';--
    
    INSERT INTO SMY.CR_CRD_SMY(
         CRD_NO                   --卡号
        ,CR_CRD_TP_ID             --卡类型
        ,CRD_Brand_TP_Id          --卡品牌类型
        ,CRD_PRVL_TP_ID           --卡级别
        ,ENT_IDV_IND              --卡对象
        ,MST_CRD_IND              --主/副卡标志
        ,NGO_CRD_IND              --协议卡类型
        ,MULT_CCY_F               --双币卡标志
        ,AST_RSK_ASES_RTG_TP_CD   --资产风险分类
        ,LN_FIVE_RTG_STS          --贷款五级形态类型
        ,PD_GRP_CD                --产品类
        ,PD_SUB_CD                --产品子代码
        ,CRD_LCS_TP_ID            --卡状态
        ,OU_ID                    --受理机构号
        ,CCY                      --币种
        ,ISSU_CRD_OU_Id           --发卡机构号
        ,TMP_CRED_LMT             --临时授信金额
        ,CR_LMT                   --授信额度
        ,AC_AR_Id                 --相关账号
        ,AC_BAL_AMT               --账户余额
        ,DEP_BAL_CRD              --银行卡存款余额
        ,OD_BAL_AMT               --透支余额
        ,AMT_PNP_ARS              --透支本金
        ,OTSND_AMT_RCVB           --应收账款余额
        ,FEE_RCVB                 --应收费用
        ,INT_RCVB                 --应收利息
        ,AMT_RCVD_For_LST_TM_OD   --本期还的上个月之前的金额
        ,AMT_RCVD                 --已还款金额
        ,EFF_DT                   --卡启用日期
        ,END_DT                   --销户日期
        ,CST_ID                   --客户内码
        ,LST_CST_AVY_DT           --客户最后活动日期
        ,EXP_MTH_YEAR             --到期年月
        ,CRD_CHG_DT               --换卡日期
        ,CRD_DLVD_DT              --开卡日期
        ,BIZ_CGY_TP_ID            --业务类别
        ,CST_NO	                  --客户号
        ,CST_NM	                  --客户名称
        ,CST_CR_RSK_RTG_ID	      --客户资信等级
        ,AC_RVL_LMT_AC_F          --循环账户标志
        ,AC_BYND_LMT_F            --超限账户标志
        ,DEP_ACG_SBJ_ID           --存款科目
        ,OD_ACG_SBJ_ID            --透支科目
        ,DRMT_CRD_F               --睡眠卡标志
        ,INT_RCVB_EXCPT_OFF_BST   --应收利息(不包含表外)
        ,CRD_MEDA_TP_ID           --卡介质
        ,IS_OLD_CRD_FLG           --是否老卡（换卡和升级卡产生的,1-老卡,0-非老卡)
        ,AC_AR_LCS_TP_ID          --账户状态
        ,ODUE_AMT                 --生息金额（已过免息期金额）
        ,LGR_INSTL_LMT            --大额分期额度 20140303 CHENPENG ADD
        ,INSTL_BAL                --分期未摊金额 20140331 CHENPENG ADD 
    )
    WITH TMP_CR_CRD AS (
        SELECT 
             CC_NO,CC_TP_ID,MST_CRD_IND,PD_CD,APL_ACPT_OU_IP_ID,PRIM_CCY_ID
            ,ISSU_CRD_OU_IP_ID,EXP_MTH_YEAR,ISSU_SEQ_NO,CRD_DLVD_DT,AC_AR_ID,UPD_CRD_NO
            ,row_number() over(partition by FORMR_CRD_NO order by ISSU_SEQ_NO desc) as ROW_NUM
        FROM SOR.CR_CRD WHERE DEL_F=0
    ),TMP_CC_STMT_INF AS (
        SELECT 
             REPYMT_RSLT_TP_ID
            ,AC_AR_ID
            ,row_number() over(partition by AC_AR_ID order by STMT_MTH desc) as ROW_NUM
        FROM SOR.CC_STMT_INF WHERE DEL_F=0
    )
    SELECT 
         CR_CRD.CC_NO                                          --卡号
        ,CR_CRD.CC_TP_ID                                       --卡类型
        ,CR_CRD_PD.CRD_BRND_TP_ID                              --卡品牌类型
        ,CR_CRD_PD.CRD_PRVL_TP_ID                              --卡级别
        ,CR_CRD_PD.ENT_IDV_CST_IND                             --卡对象
        ,CR_CRD.MST_CRD_IND                                    --主/副卡标志
        ,CRD.NGO_CRD_IND                                       --协议卡类型
        ,case when CR_CRD_PD.FX_CCY_ID ='' then 0 else 1 end   --双币卡标志
        ,COALESCE(T_CC_AC_AR.AST_RSK_ASES_RTG_TP_CD,'')        --资产风险分类
        ,COALESCE(T_CC_AC_AR.LN_FIVE_RTG_STS,-1)               --贷款五级形态类型
        ,CR_CRD_PD.PD_GRP_CD                                   --产品类
        ,CR_CRD.PD_CD                                          --产品子代码
        ,CRD.CRD_LCS_TP_ID                                     --卡状态
        ,CR_CRD.APL_ACPT_OU_IP_ID                              --受理机构号
        ,CR_CRD.PRIM_CCY_ID                                    --币种
        ,CR_CRD.ISSU_CRD_OU_IP_ID                              --发卡机构号
        ,COALESCE(T_CC_AC_AR.TMP_CRED_LMT,0)                   --临时授信金额
        ,COALESCE(T_CC_AC_AR.CR_LMT ,0)                        --授信额度
        ,CRD.AC_AR_ID                                          --相关账号
        ,COALESCE(T_CC_AC_AR.AC_BAL_AMT,0)                     --账户余额
        ,COALESCE(T_CC_AC_AR.DEP_BAL_CRD,0)                    --银行卡存款余额
        ,COALESCE(T_CC_AC_AR.OD_BAL_AMT,0)                     --透支余额
        ,COALESCE(T_CC_AC_AR.AMT_PNP_ARS,0)                    --透支本金
        --,COALESCE(T_CC_AC_AR.OTSND_AMT_RCVB,0)                 --应收账款余额 --20140303 CHENPENG DELETE
        ,COALESCE(case when COALESCE(-T_CC_AC_AR.AC_BAL_AMT+T_CC_AC_AR.INT_RCVB+T_CC_AC_AR.FEE_RCVB,0)>0 then 
                          -(COALESCE(-T_CC_AC_AR.AC_BAL_AMT+T_CC_AC_AR.INT_RCVB+T_CC_AC_AR.FEE_RCVB+T_CC_AC_AR.INSTL_BAL,0)+COALESCE(CC_AC_AR_ADDTNL_INF.TOT_LRG_INSTL_BAL,0)) 
          ELSE -(COALESCE(T_CC_AC_AR.INSTL_BAL,0)+COALESCE(CC_AC_AR_ADDTNL_INF.TOT_LRG_INSTL_BAL,0)) END,0)                 --应收账款余额 20140303 CHENPENG MODIFY
        ,COALESCE(T_CC_AC_AR.FEE_RCVB,0)                       --应收费用
        ,COALESCE(T_CC_AC_AR.INT_RCVB,0)                       --应收利息
        ,COALESCE(T_CC_AC_AR.AMT_RCVD_FOR_LST_TM_OD,0)         --本期还的上个月之前的金额
        ,COALESCE(TMP_LST_CST_AVY_DT.AMT_RCVD,0)               --已还款金额
        ,CRD.EFF_DT                                            --卡启用日期
        ,CRD.END_DT                                            --销户日期
        ,CRD.PRIM_CST_ID                                       --客户内码
        ,COALESCE(TMP_LST_CST_AVY_DT.LST_CST_AVY_DT,SMY_DATE) as LST_CST_AVY_DT         --客户最后活动日期
        ,CR_CRD.EXP_MTH_YEAR                                   --到期年月
        ,case when CR_CRD.ISSU_SEQ_NO>0 then CR_CRD.CRD_DLVD_DT else '9999-12-31' end   --换卡日期
        ,CR_CRD.CRD_DLVD_DT                                    --开卡日期
        ,CRD.BIZ_TP_ID                                         --业务类别
        ,COALESCE(CST_INF.CST_NO,'')                           --客户号
        ,COALESCE(CST_INF.CST_NM,'')                           --客户名称
        ,COALESCE(CST_INF.CST_CR_RSK_RTG_ID,-1)                --客户资信等级
        ,COALESCE(CC_AC_SMY.RVL_LMT_AC_F, -1)                  --循环账户标志
        ,COALESCE(CC_AC_SMY.BYND_LMT_F, -1)                    --超限账户标志
        ,COALESCE(T_CC_AC_AR.DEP_ACG_SBJ_ID, '')               --存款科目
        ,COALESCE(T_CC_AC_AR.OD_ACG_SBJ_ID, '')                --透支科目
        ,(case when (DAYS(SMY_DATE) - DAYS(TMP_LST_CST_AVY_DT.LST_CST_AVY_DT)>180)
            and (DAYS(SMY_DATE) - DAYS(CRD.EFF_DT)>180)
            and CR_CRD.ROW_NUM=1
            and CR_CRD.EXP_MTH_YEAR >= CUR_MTH_YEAR
            and (COALESCE(CR_CRD.UPD_CRD_NO,'')='' or CR_CRD.UPD_CRD_NO=CR_CRD.CC_NO)
            and CRD.CRD_LCS_TP_ID not in (62350001,62350009,62350012,62350013,62350008,62350011)
         then 1 else 0
         end) as DRMT_CRD_F                                    --睡眠卡标志
        ,T_CC_AC_AR.INT_RCVB - T_CC_AC_AR.CMPD_INT_BAL         --应收利息(不包含表外)
        ,CRD.CRD_MEDA_TP_ID                                    --卡介质
        ,(case when CR_CRD.ROW_NUM=1
            and (COALESCE(CR_CRD.UPD_CRD_NO,'')='' or CR_CRD.UPD_CRD_NO=CR_CRD.CC_NO)
         then 0 else 1
         end) as IS_OLD_CRD_FLG                                --是否老卡（换卡和升级卡产生的,1-老卡,0-非老卡)
        ,T_CC_AC_AR.AR_LCS_TP_ID                               --账户状态
        ,(case when TMP_CC_STMT_INF.REPYMT_RSLT_TP_ID=62430002 then T_CC_AC_AR.CASH_ADV_AMT
            else T_CC_AC_AR.CASH_ADV_AMT + T_CC_AC_AR.PRV_STMT_CNSPN_BAL + T_CC_AC_AR.PRV_STMT_INT_BAL + T_CC_AC_AR.PRV_STMT_INSTL_BAL
          end) as ODUE_AMT                                     --生息金额（已过免息期金额）
         ,COALESCE(CC_AC_AR_ADDTNL_INF.LGR_INSTL_LMT,0) --大额分期额度 20140303 CHENPENG ADD
         ,COALESCE(T_CC_AC_AR.INSTL_BAL,0)+COALESCE(CC_AC_AR_ADDTNL_INF.TOT_LRG_INSTL_BAL,0) --分期未摊金额 20140331 CHENPENG ADD 
    FROM TMP_CR_CRD AS CR_CRD 
    INNER JOIN SOR.CRD AS CRD ON CR_CRD.CC_NO=CRD.CRD_NO AND CRD.DEL_F=0
    LEFT JOIN SESSION.T_CC_AC_AR AS T_CC_AC_AR ON CRD.AC_AR_ID=T_CC_AC_AR.CC_AC_AR_ID
    LEFT JOIN SMY.CST_INF AS CST_INF ON CRD.PRIM_CST_ID =CST_INF.CST_ID
    LEFT JOIN SMY.MTHLY_CR_CRD_AC_ACML_BAL_AMT AS CC_AC_SMY ON CC_AC_SMY.AC_AR_ID = CR_CRD.AC_AR_ID AND CC_AC_SMY.CCY = CR_CRD.PRIM_CCY_ID AND CC_AC_SMY.ACG_DT=SMY_DATE
    LEFT JOIN SESSION.TMP_LST_CST_AVY_DT AS TMP_LST_CST_AVY_DT ON CR_CRD.CC_NO=TMP_LST_CST_AVY_DT.CRD_NO
    LEFT JOIN SOR.CR_CRD_PD AS CR_CRD_PD ON CR_CRD.PD_CD=CR_CRD_PD.PD_CD
    LEFT JOIN TMP_CC_STMT_INF AS TMP_CC_STMT_INF ON CR_CRD.AC_AR_ID=TMP_CC_STMT_INF.AC_AR_ID AND TMP_CC_STMT_INF.ROW_NUM=1
    LEFT JOIN SOR.CC_AC_AR_ADDTNL_INF CC_AC_AR_ADDTNL_INF ON CR_CRD.AC_AR_ID=CC_AC_AR_ADDTNL_INF.AC_AR_ID --20140303 CHENPENG ADD
    ;--
    
    /*收集操作信息*/
    GET DIAGNOSTICS SMY_RCOUNT = ROW_COUNT;--
    INSERT INTO SMY.SMY_LOG (SMY_PROC_NM,SMY_ACT_DT,SMY_STEPNUM,SMY_STEPDESC,SMY_SQLCODE,SMY_RCOUNT,CUR_TS)
      VALUES(SMY_PROCNM, SMY_DATE, SMY_STEPNUM, SMY_STEPDESC, SMY_SQLCODE, SMY_RCOUNT, CURRENT TIMESTAMP);--
    SET SMY_STEPNUM = 7;--
    SET SMY_STEPDESC = '将最新的客户最后活动日期备份到HIS表';--

    CALL SYSPROC.ADMIN_CMD('LOAD FROM (select CRD_NO,LST_CST_AVY_DT from SMY.CR_CRD_SMY)
                              OF CURSOR REPLACE INTO HIS.CR_CRD_SMY');--
    
    /*收集操作信息*/
    GET DIAGNOSTICS SMY_RCOUNT = ROW_COUNT;--
    INSERT INTO SMY.SMY_LOG (SMY_PROC_NM,SMY_ACT_DT,SMY_STEPNUM,SMY_STEPDESC,SMY_SQLCODE,SMY_RCOUNT,CUR_TS) 
        VALUES(SMY_PROCNM, SMY_DATE, SMY_STEPNUM, SMY_STEPDESC, SMY_SQLCODE, SMY_RCOUNT, CURRENT TIMESTAMP);--
    COMMIT;--
END;
SET CURRENT SCHEMA = "DWINST  ";
SET CURRENT PATH = "SYSIBM","SYSFUN","SYSPROC","SYSIBMADM","DWINST";