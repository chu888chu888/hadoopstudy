## ж������ģ��
## designer zhangfeng
## developer weiyang
## Լ�� TO CHECK ����Ҫ�������Ƶĵط�
require 'Config_Exp.pl';
#use strict; 
#use warnings;
use File::Path;
use File::Copy;
use DBI;
#use Net::FTP;
use HTTP::Date qw(time2iso str2time time2iso time2isoz);

#=================ȫ�ֱ�����==========================#
#ǰ����������ʹ��VBA��������滻
my $TABLE_NAME="GJ_BUSINESS_STATUS"; 
my @lstRlst =("SBJ_CD_1","SBJ_CD_2","SBJ_CD_3","POS_NAME","START_DEBIT_BAL","START_CREDIT_BAL","DEBIT_AMT","CREDIT_AMT","DEBIT_BAL","CREDIT_BAL","RECDATE");
my $SYS="DWIS";  #ϵͳ����
#����һ�� �ŷ壬����Ϊ�������ֶ��б���
my $datepks="[datepks]";
#����һ�� ��˧��Ϊ���ɵ��ļ����ơ�
my $FILE_NAME="YJUSD";

my $DEFAULTDATE="1000-01-01";                           #Ĭ�ϵ�����
my $DEFAULTTIMESTAMP="1000-01-01 01:01:01";             #Ĭ�ϵ�ʱ��,ֻ��ȷ����,Ϊ��ͨ��
my $ROWLENGTH=0;                                        #������¼ÿ�еĳ��� 
my $UNLOAD_SRC_DBCONN = DBI->connect("DBI:Oracle:".$ORACLE_SID,$ORACLE_USERID,$ORACLE_PASSWD) or die("DB connect error!n");
my $path=$LOCAL_FILE_PATH;
my $DW_DATA_DT="2011-12-12";






#=====================================================#
sub printlog
{
  my ($LogInfo)= @_;
  my $CurrTime = time2iso(time());                   # ��ǰʱ��
  if(!defined($LogInfo) ){$LogInfo="";}
  my $StrLog="��${CurrTime}�� \t ${LogInfo} \n"; 
  
  print $StrLog;
  #print LOGFILE $StrLog;
}
sub Errorlog(){
 eval{mkpath($path."/LOG/$DW_DATA_DT/",0,0755)};
  my $logfile=$path."/LOG/$DW_DATA_DT/".$SYS."_EXPORT.TXT";
  open(LOGFILE,">>",$logfile) or die ("open logfile failed");
  print LOGFILE $TABLE_NAME."\n";
  close(LOGFILE);		
}
sub cleanLog{
	#eval{mkpath($path."/LOG/$DW_DATA_DT/",0,0755)};

		return 1;              
	
	}
sub CreateOracleScript{
		
		printlog "��ʼ����ORACLE�������ݵ�SQL";
		
		#my @lstRlst =("NAME","SEX","AGE","BIRTHDAY","INCOME_MONTH","INCOME_YAER");
		my $exportOracleSql="SELECT ";  #���ݵ�����sql	
		#��ȡ���ÿ��б���Ϣ
		#CHAR OR VARCHAR
		#INT  ��ʵ����ȡǰ��
		#DECIMAL ��ʵ����ȡ����
		#DATE ��Ҫ�ж��Ƿ�Ϊ��
		#TIMESTAMP ��Ҫ�ж��Ƿ�Ϊ��
		eval{mkpath($path."/CONTROL/$DW_DATA_DT/".$SYS,0,0755)};
		eval{mkpath($path."/DATA/$DW_DATA_DT/".$SYS,0,0755)};
		my $control_file="${path}/CONTROL/$DW_DATA_DT/${SYS}/${TABLE_NAME}.CTL";
		my $datafile=$path."/DATA/$DW_DATA_DT/".$SYS."/".$SYS."_".$TABLE_NAME.".TXT";
		my $badfile=$path."/BAD/$DW_DATA_DT/".$SYS."/".$SYS."_".$TABLE_NAME.".BAD";
		
		my $start=1;
		my $end=0;
		my $line="LOAD DATA INFILE '$datafile'\n";
		$line=$line."APPEND INTO TABLE ${TABLE_NAME}(\n";	
		my $newline=	"LOAD DATA INFILE '$badfile'\n";
		$newline=$newline."APPEND INTO TABLE ${TABLE_NAME} fields TERMINATED by '|'  (\n";

        	        	
        	        
				
		for (my $m=0;$m<@lstRlst + 0;$m++)
		{   
				#my $columninfo=$UNLOAD_SRC_DBCONN->column_info(undef,$ ORACLE_USERID,$TABLE_NAME,$lstRlst[$m]);
				my $columninfo=$UNLOAD_SRC_DBCONN->column_info(undef,$UNLOAD_SRC_SCHEMA,$TABLE_NAME,$lstRlst[$m]);
		       $columninfo=$columninfo->fetchall_arrayref();
		    my ($srcDataType,$srcDataLength,$srcDataTrueLength)=($columninfo->[0][5],$columninfo->[0][6],$columninfo->[0][7]);
		    #printlog $lstRlst[$m]." ".$srcDataType." ".$srcDataLength." ".$srcDataTrueLength;
		    my $dataLen=0;
		    if ($srcDataLength>$srcDataTrueLength) {
		      $dataLen = $srcDataLength;
		     }
		    else{
		    	$dataLen=$srcDataTrueLength;
		    }
	    	$end=$start+$dataLen-1;	
		   		    ##############
		    if(uc($srcDataType) eq "DECIMAL" or uc($srcDataType) eq "INTEGER" or uc($srcDataType) eq "NUMBER" or uc($srcDataType) eq "FLOAT" or uc($srcDataType) eq "BIGINT"  or uc($srcDataType) eq "SMALLINT" or uc($srcDataType) eq "DOUBLE" or uc($srcDataType) eq "NUMERIC"){
		    	$line =$line.$lstRlst[$m]." POSITION($start:$end) ,\n";
		    	$newline =$newline.$lstRlst[$m]."  ,\n";		    	
	 				$start=$end+2;		    	
		    	$exportOracleSql=$exportOracleSql."TRIM(REPLACE(REPLACE(TO_CHAR(NVL(".$lstRlst[$m].",0)),CHR(10),''),CHR(13),'') )".",";		    	
		    	next;
		    	}
		   if (uc($srcDataType) eq "DATE"){
		      if (index($datepks,$lstRlst[$m])> -1) {
		    	$exportOracleSql=$exportOracleSql."TRIM(REPLACE(REPLACE(TO_CHAR(NVL(".$lstRlst[$m].",'$DEFAULTDATE')),CHR(10),''),CHR(13),'') )".",";
		    	}
		    	else{
		    	$exportOracleSql=$exportOracleSql."TRIM(REPLACE(REPLACE(NVL(TO_CHAR(NVL(".$lstRlst[$m].",''),'YYYY-MM-DD'),' '),CHR(10),''),CHR(13),'') )".",";
		      }
		    	$line =$line.$lstRlst[$m]." POSITION($start:$end) DATE \"YYYY-MM-DD\",\n";
		    	$newline =$newline.$lstRlst[$m]."   DATE \"YYYY-MM-DD\" \"ltrim(trim(:$lstRlst[$m]))\",\n";
					$start=$end+2;
		    	next;
		    	}
		   if(uc($srcDataType) eq "TIMESTAMP"){
		      if (index($datepks,$lstRlst[$m])> -1) {
		    	$exportOracleSql=$exportOracleSql."TRIM(REPLACE(REPLACE(TO_CHAR(NVL(".$lstRlst[$m].",'$DEFAULTTIMESTAMP')),CHR(10),''),CHR(13),'') )".",";
					}
		    	else{
		    	$exportOracleSql=$exportOracleSql."TRIM(REPLACE(REPLACE(NVL(TO_CHAR(NVL(".$lstRlst[$m].",''),'YYYY-MM-DD 24HH:MI:SS'),' '),CHR(10),''),CHR(13),'') )".",";
		    	}
					$line =$line.$lstRlst[$m]." POSITION($start:$end) TIMESTAMP \"YYYY-MM-DD 24HH:MI:SS\",\n";
					$newline =$newline.$lstRlst[$m]."  TIMESTAMP \"YYYY-MM-DD 24HH:MI:SS\" \"ltrim(trim(:$lstRlst[$m]))\",\n";
					$start=$end+2;
		    	next;
		    	}
		    	#δ֪���͵�,����Ĭ�Ϲ���������
		    	 $line =$line.$lstRlst[$m]." POSITION($start:$end) ,\n";	   
		    	 $newline =$newline.$lstRlst[$m]."  \"ltrim(trim(:$lstRlst[$m]))\",\n";# 	
	 				 $start=$end+2;
        	 $exportOracleSql=$exportOracleSql."TRIM(REPLACE(REPLACE(TO_CHAR(NVL(".$lstRlst[$m].",' ')),CHR(10),' '),CHR(13),' ') )".",";
		
		}
		

		#ȥ�����һ���ֶκ���Ķ���,Ȼ��󲹺�����
		$start=$end+2;
		$end = $end + 11;
		$line=$line."DW_DATA_DT POSITION($start:$end) DATE \"YYYY-MM-DD\",\n";
		$line=substr($line,0,length($line)-2);
		$newline=$newline."DW_DATA_DT   DATE \"YYYY-MM-DD\",\n";
		$newline=substr($newline,0,length($newline)-2);
		
		$line=$line.")\n";
		$newline=$newline.")\n";
		
		printlog "�����ļ����ݣ�\n".$line;
		open(CTRFILE,">",$control_file) or die (print "Open control file failed!!!\n");
		print CTRFILE $line;
		close(CTRFILE);
		open(CTRFILE,">",$control_file."1") or die (print "Open control file failed!!!\n");
		print CTRFILE $newline;
		close(CTRFILE);
		#ȥ��"||'|'"
		$exportOracleSql=substr($exportOracleSql,0,length($exportOracleSql)-1);
		my $where_str=" WHERE RECDATE=REPLACE('$DW_DATA_DT','-','')";
		$exportOracleSql=$exportOracleSql." from  $ ORACLE_USERID.$TABLE_NAME ${where_str}";	
		printlog "ORACLE��EXPORTSQL�ѹ���";
		printlog "$TABLE_NAME\'s exportsql is :\n".$exportOracleSql;		
		return $exportOracleSql;
	
	} 
	
sub Exportdata{
	    
	    printlog "��ʼ��������!";
	    my $exportsql=CreateOracleScript();
	    if($exportsql eq "error"){
	    	return -1;
	    	}
	    my $format_sql="alter session set nls_date_format='yyyy-mm-dd'";
	    my $stmt=$UNLOAD_SRC_DBCONN->prepare($format_sql);
	    unless ($stmt){
			printlog "\nִ��prepare SQL������:\n";
			printlog $DBI::errstr; 
			Errorlog;
			return -1;
			}
			$stmt->execute;
			if ($UNLOAD_SRC_DBCONN->err) {
			printlog "\nִ��SQL������:\n"; 
			printlog $DBI::errstr;
			Errorlog;
			return -1;
			}
	     $stmt=$UNLOAD_SRC_DBCONN->prepare($exportsql);
	    unless ($stmt){
			printlog "\nִ��prepare SQL������:\n";
			printlog $DBI::errstr;
			Errorlog;
			return -1;
		}
	       $stmt->execute;
		if ($UNLOAD_SRC_DBCONN->err) {
			printlog "\nִ��SQL������:\n"; 
			printlog $DBI::errstr;
			Errorlog;
			
			return -1;
		}
		
		
	     my $row=0;
	     my $size=0;
	     my $curtime;

	     
	     eval{mkpath($path."/DATA/$DW_DATA_DT/".$SYS,0,0755)};
         	if($@)
        			{ 
        			printlog "Make   path   [$path  /DATA ]   failed:\n$@";
        			return -1; 
         		}
         		
	      my $FLG_DT    = substr($DW_DATA_DT,0,4).substr($DW_DATA_DT,5,2).substr($DW_DATA_DT,8,2);
	      eval{mkpath($path."/FLAG/$SYS/".$FLG_DT,0,0755)};
         	if($@)
        			{ 
        			printlog "Make   path   [$path/FLAG ]   failed:\n$@";
        			return -1; 
         		}
	     	    printlog	$path;
	     #my $datafile=$path."/DATA/$DW_DATA_DT/".$SYS."/".$FLG_DT.$TABLE_NAME.".TXT";
	     my $datafile=$path."/DATA/$DW_DATA_DT/".$SYS."/".$FILE_NAME.$FLG_DT."01.TXT";
	    #my $flagfile=$path."/FLAG/$SYS/".$FLG_DT."/".$SYS."_".$TABLE_NAME.".FLG";


	     #���ļ��ķ�ʽ>> ׷�ӵķ�ʽ,>���ǵķ�ʽ
	    
	     open(DATAFILE,">", $datafile) || die (print "Open DATA file failed!!!\n");
	     #�ж���FLG�ļ��Ƿ���ڷ����ָ��·����COPY����ǰ·��
	     my $iniflagfrom =  $path."/FLAG/SCAN_".$SYS.".INI";
	     my $iniflagto   =  $path."/FLAG/$SYS/".$FLG_DT."/SCAN_".$SYS.".INI";
	      if(!(-e $iniflagto)){ 
	      copy($iniflagfrom , $iniflagto) || die (print "Copy file failed!!!\n");  	
	       }
	     
	    #open(FLAGFILE,"> $flagfile")|| die (print "Open FLAG file failed!!!\n");
	     printlog "�����ļ����·����".$datafile;
	    #printlog "��־�ļ����·����".$flagfile;
	     my $writeflagsql;
	     my $tmpstr="";
	     $row=0;
	     my $m=0;              
	     while(my $Rows = $stmt->fetchrow_arrayref){
	     	$m=0;
	     	$tmpstr="";
	     	foreach(@$Rows){
	     		$tmpstr=$tmpstr.$Rows->[$m]."|";
	     		$m++;
	     	}
	     	print DATAFILE $tmpstr."\n";
	     	$row++;
	     	if(($row%10000) == 0){
	     		printlog "�ѵ�������$row����";
	     	}	     	     	
	    }
     	
        	$stmt->finish;
        	my $flagfile=$path."/FLAG/$SYS/".$FLG_DT."/".$SYS."_".$TABLE_NAME.".FLG"; # NIEZF:2012-05-02,�޸��������FLAG�ļ���
        	open(FLAGFILE,"> $flagfile")|| die (print "Open FLAG file failed!!!\n");
          printlog "��־�ļ����·����".$flagfile;
        	print FLAGFILE $datafile,"\n";
        	print FLAGFILE $row,"\n";
        	close(DATAFILE);
          close(FLAGFILE);

        	$curtime=time2iso(time());
          printlog "�����ѳɹ�����!";
          printlog "һ����������${row}��";
                
          return 1;	
	
	}

sub Main{
		printlog "��ǰ����Ϊ:$DW_DATA_DT";

		#ִ��ж��
		if( Exportdata() < 0 ){
			exit -1;
		}
		printlog "�Ͽ����ݿ�����";
		$UNLOAD_SRC_DBCONN->disconnect();
		printlog "���ݿ������ѶϿ�";
		exit 0;
		
}

#�ж����ڲ����Ƿ����
if ( $#ARGV < 0 ){
        print "������һ�����ڲ�������ʽΪYYYY-MM-DD\n";
        exit(-1);
    }
#��ʼ������
   $DW_DATA_DT = $ARGV[0]; 
if (length($DW_DATA_DT)!=10){
	print "������ʽ����ΪYYYY-MM-DD\n";
	exit (-1);
}
   #������YYYY-MM-DD�����ڸ�ʽ
Main();
