date=`echo $1`
var_dt=`echo $date | sed 's/\-//g'`
cd  /home/dataun/ETL_init/DATA
if [ -d "$date" ]
then
echo ok
else
mkdir "$date"
fi 
cd /home/dataun/ETL_init/DATA/"$date"
if [ -d /"$date"/CQCS ]
then
echo ok
else
mkdir CQCS
fi 
      cd /home/dataun/ETL_init/DATA/"$date"/CQCS
touch "$var_dt"CQCS.ok
