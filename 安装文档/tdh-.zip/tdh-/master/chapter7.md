# 第八章：Eistic search

全文索引，在HBase中建立索引就可以search了