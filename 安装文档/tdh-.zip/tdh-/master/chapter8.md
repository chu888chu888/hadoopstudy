# 第九章：Kafka

kafka是一种基于发布/订阅的消息系统，broker包含一个或多个服务器，topic为消息的类别，producer分发到kafka broker中

